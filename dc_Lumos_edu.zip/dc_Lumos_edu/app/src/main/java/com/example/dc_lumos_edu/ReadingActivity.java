package com.example.dc_lumos_edu;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Surface;
import android.view.TextureView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.dc_lumos_edu.ml.ModelUnquant;

import org.tensorflow.lite.DataType;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Collections;

public class ReadingActivity extends AppCompatActivity {

    private TextView tv;
    private CameraDevice cameraDevice;
    private Handler handler;
    private CameraManager cameraManager;
    private TextureView textureView;
    private ModelUnquant model;
    private Bitmap bitmap;

    private TextView exampleTextView;
    private final Handler detectionHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);
        getPermission();


        // Initialize TensorFlow Lite model
        try {
            model = ModelUnquant.newInstance(this);
        } catch (Exception e) {
            e.printStackTrace();
        }

        HandlerThread handlerThread = new HandlerThread("videoThread");
        handlerThread.start();
        handler = new Handler(handlerThread.getLooper());

        tv = findViewById(R.id.tv);
        textureView = findViewById(R.id.textureView);

        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
                openCamera();
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {}

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                return false;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
                bitmap = textureView.getBitmap();
            }
        });

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        // Schedule the detection to run once after 10 seconds from page load
        detectionHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (bitmap != null) {
                    Toast.makeText(ReadingActivity.this, "Detection started", Toast.LENGTH_SHORT).show();
                    processImage(bitmap);
                } else {
                    Toast.makeText(ReadingActivity.this, "No image available for detection", Toast.LENGTH_SHORT).show();
                }
            }
        }, 30000); // reading time is 30 seconds
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (model != null) {
            model.close();
        }
        detectionHandler.removeCallbacksAndMessages(null);
    }

    @SuppressLint("MissingPermission")
    private void openCamera() {
        try {
            for (String cameraId : cameraManager.getCameraIdList()) {
                CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(cameraId);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);

                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                        @Override
                        public void onOpened(@NonNull CameraDevice cameraDevice) {
                            ReadingActivity.this.cameraDevice = cameraDevice;
                            SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
                            Surface surface = new Surface(surfaceTexture);

                            try {
                                CaptureRequest.Builder captureRequest = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                captureRequest.addTarget(surface);

                                cameraDevice.createCaptureSession(Collections.singletonList(surface), new CameraCaptureSession.StateCallback() {
                                    @Override
                                    public void onConfigured(@NonNull CameraCaptureSession session) {
                                        try {
                                            session.setRepeatingRequest(captureRequest.build(), null, handler);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    @Override
                                    public void onConfigureFailed(@NonNull CameraCaptureSession session) {}
                                }, handler);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onDisconnected(@NonNull CameraDevice cameraDevice) {}

                        @Override
                        public void onError(@NonNull CameraDevice cameraDevice, int error) {}
                    }, handler);
                    break; // Once the front camera is found, stop the loop
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processImage(Bitmap bitmap) {
        Toast.makeText(this, "Running detection...", Toast.LENGTH_SHORT).show();

        // Convert Bitmap to ByteBuffer
        Bitmap resizedImage = Bitmap.createScaledBitmap(bitmap, 224, 224, true);
        ByteBuffer byteBuffer = convertBitmapToByteBuffer(resizedImage);

        // Create inputs for model
        TensorBuffer inputFeature0 = TensorBuffer.createFixedSize(new int[]{1, 224, 224, 3}, DataType.FLOAT32);
        inputFeature0.loadBuffer(byteBuffer);

        // Run model inference
        ModelUnquant.Outputs outputs = model.process(inputFeature0);
        TensorBuffer outputFeature0 = outputs.getOutputFeature0AsTensorBuffer();

        // Define emotion labels
        String[] emotions = {"No Face Found...", "disgusted", "No Face Found...", "happy", "neutral", "sad", "surprised"};

        // Get the output probabilities
        float[] probabilities = outputFeature0.getFloatArray();

        // Check if probabilities are empty or not
        if (probabilities.length == 0) {
            tv.setText("No faces found");
        } else {
            // Use the built-in function to get the index of the max value
            int maxIndex = getMaxIndex(probabilities);
            String detectedEmotion = emotions[maxIndex];

            // Display the corresponding emotion label
            tv.setText(detectedEmotion);
            Intent intent = new Intent(ReadingActivity.this, MainActivity.class);
            intent.putExtra("detectedEmotion", detectedEmotion);
            startActivity(intent);
        }
    }

    // Helper method to find the index of the maximum value in an array
    private int getMaxIndex(float[] probabilities) {
        float max = probabilities[0];
        int maxIndex = 0;

        for (int i = 1; i < probabilities.length; i++) {
            if (probabilities[i] > max) {
                max = probabilities[i];
                maxIndex = i;
            }
        }

        return maxIndex;
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * 224 * 224 * 3);
        byteBuffer.order(ByteOrder.nativeOrder());
        int[] intValues = new int[224 * 224];
        bitmap.getPixels(intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());

        int pixel = 0;
        for (int i = 0; i < 224; i++) {
            for (int j = 0; j < 224; j++) {
                int val = intValues[pixel++];
                byteBuffer.putFloat(((val >> 16) & 0xFF) * (1f / 255f));
                byteBuffer.putFloat(((val >> 8) & 0xFF) * (1f / 255f));
                byteBuffer.putFloat((val & 0xFF) * (1f / 255f));
            }
        }
        return byteBuffer;
    }

    private void getPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // Permission granted
        } else {
            // Permission denied
        }
    }
}
