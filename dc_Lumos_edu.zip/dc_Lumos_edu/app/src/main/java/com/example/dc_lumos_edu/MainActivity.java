package com.example.dc_lumos_edu;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;


import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class    MainActivity extends AppCompatActivity {

    private TextView levelTextView;
    private TextView questionNumberTextView;
    private TextView questionTextView;
    private EditText answerEditText;
    private Button submitAnswerButton;
    private TextView scoreTextView;

    private int correctAnswer;
    private int score = 0;
    private int currentLevel = 1;
    private int currentQuestion = 1;
    private final int maxLevels = 4;
    private final int questionsPerLevel = 5;
    private int[] levelScores = new int[maxLevels];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        levelTextView = findViewById(R.id.levelTextView);
        questionNumberTextView = findViewById(R.id.questionNumberTextView);
        questionTextView = findViewById(R.id.questionTextView);
        answerEditText = findViewById(R.id.answerEditText);
        submitAnswerButton = findViewById(R.id.submitAnswerButton);
        scoreTextView = findViewById(R.id.scoreTextView);

        generateNewQuestion();

        submitAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });

        // Requesting write permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    private void generateNewQuestion() {
        Random random = new Random();
        int number1 = random.nextInt(10 * currentLevel) + 1;
        int number2 = random.nextInt(10 * currentLevel) + 1;

        switch (currentLevel) {
            case 1:
                correctAnswer = number1 + number2;
                questionTextView.setText(number1 + " + " + number2 + " = ?");
                break;
            case 2:
                correctAnswer = number1 - number2;
                questionTextView.setText(number1 + " - " + number2 + " = ?");
                break;
            case 3:
                correctAnswer = number1 * number2;
                questionTextView.setText(number1 + " * " + number2 + " = ?");
                break;
            case 4:
                // Ensure that division results in an integer answer
                if (number2 == 0) {
                    number2 = 1; // Avoid division by zero
                }
                number1 = number1 * number2; // Ensure number1 is a multiple of number2
                correctAnswer = number1 / number2;
                questionTextView.setText(number1 + " / " + number2 + " = ?");
                break;
        }

        answerEditText.setText("");
        updateUI();
    }

    private void checkAnswer() {
        String answerText = answerEditText.getText().toString();
        if (!answerText.isEmpty()) {
            int userAnswer = Integer.parseInt(answerText);
            if (userAnswer == correctAnswer) {
                score=score + 1;
                levelScores[currentLevel - 1]++;
                showAlertDialog("Correct!", "Well done!");
            } else {
                showAlertDialog("Incorrect", "The correct answer was " + correctAnswer);
            }
            scoreTextView.setText("Score: " + score);
            currentQuestion++;
            if (currentQuestion > questionsPerLevel) {
                currentLevel++;
                currentQuestion = 1;
                if (currentLevel > maxLevels) {
                    showFinalScoreDialog();
                    resetGame();
                }
            }
            generateNewQuestion();
        } else {
            showAlertDialog("Error", "Please enter an answer.");
        }
    }

    private void updateUI() {
        levelTextView.setText("Level: " + currentLevel);
        questionNumberTextView.setText("Question: " + currentQuestion + "/" + questionsPerLevel);
    }

    private void resetGame() {
        score = 0;
        currentLevel = 1;
        currentQuestion = 1;
        scoreTextView.setText("Score: " + score);
        for (int i = 0; i < maxLevels; i++) {
            levelScores[i] = 0;
        }
        generateNewQuestion();
    }

    private void showAlertDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        builder.show();
    }



    private void showFinalScoreDialog() {
        StringBuilder finalScores = new StringBuilder();
        for (int i = 0; i < maxLevels; i++) {
            finalScores.append("Level ").append(i + 1).append(": ").append(levelScores[i]).append("/").append(questionsPerLevel).append("\n");
        }


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Game Over" );
        builder.setMessage("You completed all levels! Your final score is " + score + "\n\n" + finalScores.toString());
        builder.setPositiveButton("Download PDF", (dialog, which) -> generatePdf(finalScores.toString()));
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void generatePdf(String scoreText) {
        String fileName = "MathQuizScores.pdf";
        Context context = getApplicationContext();
        Uri pdfUri = savePdf(context, fileName, scoreText);

        if (pdfUri != null) {
            showAlertDialog("Success", "PDF saved at " + pdfUri.getPath());
        } else {
            showAlertDialog("Error", "Could not save PDF");
        }
    }


    private Uri savePdf(Context context, String fileName, String scoreText) {
        Uri pdfUri = null;

        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS);

            pdfUri = context.getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);

            if (pdfUri != null) {
                OutputStream outputStream = context.getContentResolver().openOutputStream(pdfUri);

                if (outputStream != null) {

                    Intent intent = getIntent();
                    String detectedEmotion = null;

                    if (intent != null) {
                        detectedEmotion = intent.getStringExtra("detectedEmotion");
                    }

                    PdfWriter writer = new PdfWriter(outputStream);
                    PdfDocument pdfDoc = new PdfDocument(writer);
                    Document document = new Document(pdfDoc);

                    document.add(new Paragraph("Math Quiz Scores"));


                    document.add(new Paragraph(scoreText));

                    document.add(new Paragraph("Detected Emotion : " + detectedEmotion));


                    document.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pdfUri;
    }
}
